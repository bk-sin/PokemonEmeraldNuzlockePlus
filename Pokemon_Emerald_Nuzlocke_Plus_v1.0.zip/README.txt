Pokemon Emerald Nuzlocke Plus v1.0
Apply "Pokemon Emerald Nuzlocke Plus.bps" to an unmodified Pokemon Emerald (USA) ROM
(SHA1 f3ae088181bf583e55daf962a92bb46f4f1d07b7, CRC32 1F1C08FB) with Floating IPS (Flips) or Rom Patcher JS.
Patched result: SHA1 cced8cf8101bac7baf45d6f3047d91e7953a5100 (32 MB). Save type: Flash 128K.
Strategy set data adapted from Pokexperto (pokexperto.net, CC BY-NC-SA 3.0) and Smogon (via data.pkmn.cc).
